#!/bin/bash
cp PDARun.jar ~/
touch ~/.pdarun.sh
echo "

#!/bin/bash

function pdarun(){
    java -jar ~/PDARun.jar \$1
}" >> ~/.pdarun.sh
source ~/.pdarun.sh
echo "source ~/.pdarun.sh" >> ~/.bashrc
exit
